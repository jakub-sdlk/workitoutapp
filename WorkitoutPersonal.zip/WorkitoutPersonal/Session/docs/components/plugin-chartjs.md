## Chart.js

Charts and graphs are available through [Chart.js](http://www.chartjs.org), a clean and responsive canvas-based chart rendering JavaScript library.

We recommend reviewing the full [Chart.js documentation](http://www.chartjs.org/docs/) as you implement or modify any charts here.
